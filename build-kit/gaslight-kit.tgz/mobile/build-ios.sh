#!/bin/bash
# Builds an unsigned Gaslight.ipa (users sign it with their own Apple ID via Sideloadly/AltStore).
set -euo pipefail
V="$1"; B="$2"
rm -rf www && cp -R ../desktop/dist www
[ -d ios ] || npx cap add ios
PL=ios/App/App/Info.plist
plutil -replace CFBundleDisplayName -string "Gaslight" "$PL"
plutil -replace NSAppTransportSecurity -json '{"NSAllowsArbitraryLoads":true,"NSAllowsLocalNetworking":true}' "$PL"
plutil -replace NSLocalNetworkUsageDescription -string "Gaslight finds and joins murder mystery rooms on your Wi-Fi." "$PL"
plutil -replace NSCameraUsageDescription -string "Gaslight scans room QR codes and hidden clues." "$PL"
plutil -replace NSMicrophoneUsageDescription -string "Gaslight can record audio clips for your mysteries." "$PL"
plutil -replace NSPhotoLibraryUsageDescription -string "Gaslight can use your photos as portraits and evidence." "$PL"
plutil -replace CFBundleURLTypes -json '[{"CFBundleURLName":"app.gaslight.mystery","CFBundleURLSchemes":["gaslight"]}]' "$PL"
plutil -replace ITSAppUsesNonExemptEncryption -bool NO "$PL"
for f in ios/App/App/Assets.xcassets/AppIcon.appiconset/*.png; do cp assets/AppIcon-1024.png "$f"; done
for f in ios/App/App/Assets.xcassets/Splash.imageset/*.png; do cp assets/splash-2732.png "$f"; done
npx cap sync ios
cd ios/App
if [ -d App.xcworkspace ]; then T=(-workspace App.xcworkspace); else T=(-project App.xcodeproj); fi
xcodebuild "${T[@]}" -scheme App -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath ../../xcbuild CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  MARKETING_VERSION="$V" CURRENT_PROJECT_VERSION="$B" build | tail -n 40
cd ../..
APP=$(find xcbuild/Build/Products/Release-iphoneos -maxdepth 1 -name '*.app' | head -1)
rm -rf out && mkdir -p out/Payload && cp -R "$APP" out/Payload/
(cd out && zip -qry "Gaslight-$V.ipa" Payload && rm -rf Payload)
ls -la out
